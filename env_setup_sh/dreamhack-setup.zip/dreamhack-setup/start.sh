#!/usr/bin/env bash
# 드림핵 환경 시작: 환경이 없으면 자동 세팅 후, 가상환경이 켜진 터미널을 엽니다.
# 사용법: bash start.sh

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$HOME/dreamhack-venv"
export PATH="$HOME/.local/bin:$PATH"

# 환경이 없거나 필수 모듈이 없으면 세팅 실행
if [ ! -x "$VENV_DIR/bin/python" ] || ! "$VENV_DIR/bin/python" -c "import flask, requests, selenium" 2>/dev/null; then
    echo "환경 세팅을 시작합니다 (처음 한 번만 걸려요)..."
    bash "$DIR/dh_setup.sh" || { echo "세팅 실패. 위 오류 메시지를 확인하세요."; exit 1; }
else
    echo "환경이 이미 준비되어 있습니다."
fi

# source start.sh 로 실행했다면 현재 터미널에서 바로 활성화
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
    source "$VENV_DIR/bin/activate"
    echo "가상환경 활성화 완료"
    return 0
fi

# bash start.sh 로 실행했다면 활성화된 새 셸을 엽니다 (종료는 exit)
echo "가상환경이 켜진 터미널로 들어갑니다. 나가려면 exit 입력."
cd "$HOME"
RCFILE="$(mktemp)"
cat > "$RCFILE" << RC
[ -f ~/.bashrc ] && source ~/.bashrc
source "$VENV_DIR/bin/activate"
export PATH="\$HOME/.local/bin:\$PATH"
rm -f "$RCFILE"
RC
exec bash --rcfile "$RCFILE" -i
