#!/usr/bin/env bash
# 드림핵 환경 시작: 환경이 없으면 자동 세팅 후, 가상환경이 켜진 터미널을 엽니다.
# 기본 app.py 경로: ~/다운로드/deploy/app.py (인자로 다른 경로를 주면 그걸 사용)
#
# 사용법:
#   bash start.sh                          (기본 경로 ~/다운로드/deploy/app.py 자동 패치)
#   bash start.sh ~/다른경로/app.py         (경로 직접 지정)
#   bash start.sh none                     (app.py 패치 건너뜀)

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$HOME/dreamhack-venv"
CHROME_BIN="$HOME/opt/chrome/opt/google/chrome/google-chrome"
CHROMEDRIVER_BIN="$HOME/opt/chromedriver"
DEFAULT_APP_PATH="$HOME/다운로드/deploy/app.py"
export PATH="$HOME/.local/bin:$PATH"

ARG="${1:-}"
if [ "$ARG" = "none" ]; then
    APP_PATH=""
elif [ -n "$ARG" ]; then
    APP_PATH="$ARG"
else
    APP_PATH="$DEFAULT_APP_PATH"
fi

NEED_SETUP=0
[ -x "$VENV_DIR/bin/python" ] || NEED_SETUP=1
"$VENV_DIR/bin/python" -c "import flask, requests, selenium" 2>/dev/null || NEED_SETUP=1
[ -x "$CHROME_BIN" ] || NEED_SETUP=1
[ -x "$CHROMEDRIVER_BIN" ] || NEED_SETUP=1

if [ "$NEED_SETUP" = "1" ]; then
    echo "환경 세팅을 시작합니다 (처음 한 번만 걸려요)..."
    bash "$DIR/dh_setup.sh" || { echo "세팅 실패. 위 오류 메시지를 확인하세요."; exit 1; }
else
    echo "환경이 이미 준비되어 있습니다."
fi

if [ -n "$APP_PATH" ]; then
    if [ -f "$APP_PATH" ]; then
        bash "$DIR/patch_app.sh" "$APP_PATH"
    else
        echo "참고: app.py를 찾을 수 없음 ($APP_PATH) — 아직 문제를 안 받았다면 무시해도 됩니다."
    fi
fi

# source start.sh 로 실행했다면 현재 터미널에서 바로 활성화
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
    source "$VENV_DIR/bin/activate"
    echo "가상환경 활성화 완료"
    return 0
fi

echo "가상환경이 켜진 터미널로 들어갑니다. 나가려면 exit 입력."
cd "$HOME"
RCFILE="$(mktemp)"
cat > "$RCFILE" << RC
[ -f ~/.bashrc ] && source ~/.bashrc
source "$VENV_DIR/bin/activate"
export PATH="\$HOME/.local/bin:\$PATH"
rm -f "$RCFILE"
RC
exec bash --rcfile "$RCFILE" -i
