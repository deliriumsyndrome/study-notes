#!/usr/bin/env bash
# 드림핵 문제 풀이 환경 세팅 (sudo 불필요, 여러 번 실행해도 안전)

PY_VERSION="3.10"
VENV_DIR="$HOME/dreamhack-venv"
PACKAGES="flask requests selenium"   # 필요한 패키지를 여기에 추가

export PATH="$HOME/.local/bin:$PATH"

echo "[1/4] uv 확인"
if ! command -v uv >/dev/null 2>&1; then
    echo " -> uv 설치 중..."
    curl -LsSf https://astral.sh/uv/install.sh | sh || { echo "uv 설치 실패 (인터넷 확인)"; exit 1; }
    export PATH="$HOME/.local/bin:$PATH"
fi
uv --version || { echo "uv를 찾을 수 없음"; exit 1; }

echo "[2/4] 가상환경 확인 ($VENV_DIR)"
if [ ! -x "$VENV_DIR/bin/python" ]; then
    uv venv --python "$PY_VERSION" "$VENV_DIR" || { echo "가상환경 생성 실패"; exit 1; }
else
    echo " -> 이미 존재, 건너뜀"
fi

echo "[3/4] 패키지 설치: $PACKAGES"
uv pip install --python "$VENV_DIR/bin/python" $PACKAGES || { echo "패키지 설치 실패"; exit 1; }

echo "[4/4] 설치 확인"
"$VENV_DIR/bin/python" - << 'PYEOF'
import sys
print("Python:", sys.version.split()[0])
for name in ["flask", "requests", "selenium"]:
    try:
        mod = __import__(name)
        print(f"{name}: OK ({getattr(mod, '__version__', '?')})")
    except ImportError:
        print(f"{name}: 없음")
PYEOF

echo "세팅 완료"
