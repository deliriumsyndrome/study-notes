#!/usr/bin/env bash
# 드림핵 문제 풀이 환경 통합 세팅 (sudo 불필요, 여러 번 실행해도 안전)
# - 파이썬 3.10 가상환경 (uv)
# - flask, requests, selenium
# - Chrome + chromedriver (홈 디렉터리에 설치, selenium 봇 로컬 재현용)

set -u

PY_VERSION="3.10"
VENV_DIR="$HOME/dreamhack-venv"
PACKAGES="flask requests selenium"   # 필요한 패키지를 여기에 추가
OPT_DIR="$HOME/opt"
CHROME_BIN="$OPT_DIR/chrome/opt/google/chrome/google-chrome"
CHROMEDRIVER_BIN="$OPT_DIR/chromedriver"

export PATH="$HOME/.local/bin:$PATH"

# ---------- 1. 파이썬 / venv ----------
echo "[1/5] uv 확인"
if ! command -v uv >/dev/null 2>&1; then
    echo " -> uv 설치 중..."
    curl -LsSf https://astral.sh/uv/install.sh | sh || { echo "uv 설치 실패 (인터넷 확인)"; exit 1; }
    export PATH="$HOME/.local/bin:$PATH"
fi
uv --version || { echo "uv를 찾을 수 없음"; exit 1; }

echo "[2/5] 가상환경 확인 ($VENV_DIR)"
if [ ! -x "$VENV_DIR/bin/python" ]; then
    uv venv --python "$PY_VERSION" "$VENV_DIR" || { echo "가상환경 생성 실패"; exit 1; }
else
    echo " -> 이미 존재, 건너뜀"
fi

echo "[3/5] 패키지 설치: $PACKAGES"
uv pip install --python "$VENV_DIR/bin/python" $PACKAGES || { echo "패키지 설치 실패"; exit 1; }

# ---------- 2. Chrome ----------
echo "[4/5] Chrome 확인"
mkdir -p "$OPT_DIR"
if [ -x "$CHROME_BIN" ]; then
    echo " -> 이미 설치됨: $("$CHROME_BIN" --version)"
else
    echo " -> Chrome 설치 중..."
    cd "$OPT_DIR"
    wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb || { echo "Chrome 다운로드 실패"; exit 1; }
    dpkg-deb -x google-chrome-stable_current_amd64.deb "$OPT_DIR/chrome"
    rm -f google-chrome-stable_current_amd64.deb
    if ! "$CHROME_BIN" --version >/dev/null 2>&1; then
        echo "Chrome 실행 실패 (공유 라이브러리 부족 가능성). google-chrome --version 오류를 확인하세요."
        "$CHROME_BIN" --version
        exit 1
    fi
    echo " -> 설치 완료: $("$CHROME_BIN" --version)"
fi

# ---------- 3. chromedriver (설치된 Chrome 버전에 맞춰 자동 매칭) ----------
echo "[5/5] chromedriver 확인"
if [ -x "$CHROMEDRIVER_BIN" ]; then
    echo " -> 이미 설치됨: $("$CHROMEDRIVER_BIN" --version)"
else
    CHROME_VERSION=$("$CHROME_BIN" --version | grep -oP '\d+\.\d+\.\d+\.\d+')
    echo " -> 설치된 Chrome 버전: $CHROME_VERSION"
    curl -s "https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json" -o /tmp/cft_versions.json

    DRIVER_URL=$(python3 - "$CHROME_VERSION" << 'PYEOF'
import json, sys
target = sys.argv[1]
data = json.load(open('/tmp/cft_versions.json'))
match = next((v for v in reversed(data['versions']) if v['version'] == target), None)
if not match:
    major = target.split('.')[0]
    match = next((v for v in reversed(data['versions']) if v['version'].split('.')[0] == major), None)
if not match:
    sys.exit(1)
for d in match['downloads'].get('chromedriver', []):
    if d['platform'] == 'linux64':
        print(d['url'])
        break
PYEOF
)
    if [ -z "$DRIVER_URL" ]; then
        echo "Chrome 버전($CHROME_VERSION)에 맞는 chromedriver를 찾지 못했습니다."
        exit 1
    fi
    echo " -> chromedriver 다운로드: $DRIVER_URL"
    cd "$OPT_DIR"
    wget -q "$DRIVER_URL" -O chromedriver.zip || { echo "chromedriver 다운로드 실패"; exit 1; }
    unzip -oq chromedriver.zip
    DRIVER_PATH=$(find "$OPT_DIR" -maxdepth 2 -name chromedriver -type f | head -1)
    mv "$DRIVER_PATH" "$CHROMEDRIVER_BIN"
    chmod +x "$CHROMEDRIVER_BIN"
    rm -rf chromedriver.zip chromedriver-linux64
    echo " -> 설치 완료: $("$CHROMEDRIVER_BIN" --version)"
fi

# ---------- 4. 최종 확인 ----------
echo
echo "===== 설치 확인 ====="
"$VENV_DIR/bin/python" - << 'PYEOF'
import sys
print("Python:", sys.version.split()[0])
for name in ["flask", "requests", "selenium"]:
    try:
        mod = __import__(name)
        print(f"{name}: OK ({getattr(mod, '__version__', '?')})")
    except ImportError:
        print(f"{name}: 없음")
PYEOF
echo "Chrome:       $("$CHROME_BIN" --version 2>/dev/null)"
echo "chromedriver: $("$CHROMEDRIVER_BIN" --version 2>/dev/null)"
echo "세팅 완료"
