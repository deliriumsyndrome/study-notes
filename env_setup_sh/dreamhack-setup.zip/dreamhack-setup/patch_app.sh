#!/usr/bin/env bash
# 문제의 app.py 안 Chrome/chromedriver 경로를 로컬 설치 경로로 자동 교체
# 사용법: bash patch_app.sh <app.py 경로>

set -u
OPT_DIR="$HOME/opt"
CHROME_BIN="$OPT_DIR/chrome/opt/google/chrome/google-chrome"
CHROMEDRIVER_BIN="$OPT_DIR/chromedriver"

TARGET="${1:-}"
if [ -z "$TARGET" ] || [ ! -f "$TARGET" ]; then
    echo "사용법: bash patch_app.sh <app.py 경로>"
    exit 1
fi

if [ ! -f "${TARGET}.bak" ]; then
    cp "$TARGET" "${TARGET}.bak"
    echo "원본 백업: ${TARGET}.bak"
fi

sed -i "s|/usr/local/bin/chromedriver|$CHROMEDRIVER_BIN|g" "$TARGET"
sed -i "s|/usr/bin/google-chrome|$CHROME_BIN|g" "$TARGET"

echo "패치 완료. 변경된 경로:"
grep -n "chromedriver\|google-chrome" "$TARGET"
