드림핵 환경 자동 세팅 (파이썬 + Chrome + chromedriver 통합)
=============================================================

기본 사용법 (가장 흔한 경우: 문제를 ~/다운로드/deploy/app.py 로 받을 때)
---------------------------------------------------------------------
  bash start.sh

인자 없이 실행하면:
  1. 환경(파이썬 venv, flask/requests/selenium, Chrome, chromedriver)이
     없으면 전부 자동 설치 (sudo 불필요)
  2. ~/다운로드/deploy/app.py 가 있으면 Chrome/chromedriver 경로를
     자동으로 패치 (원본은 app.py.bak 으로 백업)
  3. 가상환경이 켜진 터미널로 진입 (나가기: exit)

현재 터미널에서 바로 쓰려면: source start.sh


app.py 경로가 다를 때
----------------------
  bash start.sh ~/다운로드/다른폴더/app.py

패치를 아예 건너뛰고 싶을 때 (예: selenium 안 쓰는 단순 문제)
  bash start.sh none


app.py 하나만 따로 패치하고 싶을 때
-------------------------------------
  bash patch_app.sh ~/다운로드/deploy/app.py


실행 흐름 요약
--------------
  bash start.sh              # 환경 켜기 + app.py 자동 패치
  cd ~/다운로드/deploy
  python3 app.py


참고
----
- 패키지를 추가하려면 dh_setup.sh 위쪽의 PACKAGES 줄을 수정하세요.
- 홈 디렉터리가 /tmp 아래라 재로그인하면 전부 사라질 수 있습니다.
  그때는 이 폴더에서 bash start.sh 만 다시 실행하면 전부 복구됩니다
  (이미 받은 건 건너뛰므로 두 번째부터는 빠릅니다).
- Chrome 실행 시 "shared libraries" 오류가 나면 이 PC에서는 로컬
  Chrome 재현이 어려운 경우이니, 드림핵 사이트에서 문제 서버를
  생성해 그쪽에서 최종 제출하면 됩니다.
- selenium을 쓰지 않는 단순 flask 문제는 패치가 필요 없습니다.
  source ~/dreamhack-venv/bin/activate 후 바로 python3 app.py 하면 됩니다.
